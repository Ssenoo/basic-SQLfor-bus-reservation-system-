

create table userss(
userID int primary key identity,
firstname varchar(10) not null,
lastname varchar(10)null,
Email varchar(40) unique null,
phonenum int unique not null,
passwordd varchar(20) not null
);





create table driver(
driverId int primary key identity,
firstname varchar(10) not null,
lastname varchar(10)null,
Email varchar(30) unique  not null,
licensenum int unique  not null,
);





create table Bus(
BusId int primary key identity,
capacity int not null,
model varchar(10)null,
manufacturer varchar(30) null,
registrationnum int unique  not null,

DriverID int,
foreign key (DriverID) REFERENCES  driver(driverID)
);



create table Routess(
RoutesId int primary key identity,
routename varchar(30) not null,
pickuplocation varchar(30) not null,
dropofflocation varchar(30) not null,

busID int,
foreign key (busID) REFERENCES  Bus(BusId)
);


create table trips(
TripsId int primary key identity,
statuss int not null,
numofseats varchar(10) not null,
pickuptime datetime not null,
dropofftime datetime  not null,


busID int,
routeID int,
foreign key (busID) REFERENCES  Bus(BusId),
foreign key (routeID) REFERENCES  Routess(RoutesId)

);




create table user_trips(

userID int ,
tripsID int,
primary key(userID,tripsID),
foreign key (userID) REFERENCES  userss(userID),
foreign key (tripsID) REFERENCES  trips(TripsId)

);



INSERT INTO userss (firstname, lastname, Email, phonenum, passwordd)
VALUES
('Ali', 'Ahmed', 'ali1@example.com', 1234567890, 'pass123'),
('Sara', 'Mohamed', 'sara2@example.com', 1234567891, 'pass456'),
('John', 'Doe', 'john3@example.com', 1234567892, 'pass789'),
('Jane', 'Smith', 'jane4@example.com', 1234567893, 'pass101'),
('Omar', 'Said', 'omar5@example.com', 1234567894, 'pass202'),
('Mona', 'Ali', 'mona6@example.com', 1234567895, 'pass303'),
('Khaled', 'Youssef', 'khaled7@example.com', 1234567896, 'pass404'),
('Huda', 'Samir', 'huda8@example.com', 1234567897, 'pass505'),
('Laila', 'Hassan', 'laila9@example.com', 1234567898, 'pass606'),
('Karim', 'Ibrahim', 'karim10@example.com', 1234567899, 'pass707'),
('Fadi', 'Nasser', 'fadi11@example.com', 1234567800, 'pass808'),
('Salma', 'Rami', 'salma12@example.com', 1234567801, 'pass909'),
('Tarek', 'Adel', 'tarek13@example.com', 1234567802, 'pass010'),
('Aya', 'Hisham', 'aya14@example.com', 1234567803, 'pass121'),
('Rana', 'Mansour', 'rana15@example.com', 1234567804, 'pass232'),
('Yara', 'Kamal', 'yara16@example.com', 1234567805, 'pass343'),
('Ziad', 'Tamer', 'ziad17@example.com', 1234567806, 'pass454'),
('Farah', 'Nour', 'farah18@example.com', 1234567807, 'pass565'),
('Nour', 'Ali', 'nour19@example.com', 1234567808, 'pass676'),
('Adham', 'Fathy', 'adham20@example.com', 1234567809, 'pass787');






INSERT INTO driver (firstname, lastname, Email, licensenum)
VALUES
('Ahmed', 'Hassan', 'driver1@example.com', 111111),
('Hany', 'Omar', 'driver2@example.com', 111112),
('Maged', 'Samy', 'driver3@example.com', 111113),
('Sayed', 'Zaki', 'driver4@example.com', 111114),
('Sherif', 'Kamel', 'driver5@example.com', 111115),
('Ibrahim', 'Fouad', 'driver6@example.com', 111116),
('Mahmoud', 'Farid', 'driver7@example.com', 111117),
('Eman', 'Sami', 'driver8@example.com', 111118),
('Fouad', 'Younis', 'driver9@example.com', 111119),
('Amr', 'Adel', 'driver10@example.com', 111120),
('Tamer', 'Lotfy', 'driver11@example.com', 111121),
('Gamal', 'Nashaat', 'driver12@example.com', 111122),
('Rami', 'Wael', 'driver13@example.com', 111123),
('Sameh', 'Rashad', 'driver14@example.com', 111124),
('Osama', 'Nabil', 'driver15@example.com', 111125),
('Zaki', 'Hamdy', 'driver16@example.com', 111126),
('Mounir', 'Ali', 'driver17@example.com', 111127),
('Walid', 'Hafez', 'driver18@example.com', 111128),
('Ashraf', 'Fathy', 'driver19@example.com', 111129),
('Khalil', 'Mostafa', 'driver20@example.com', 111130);


INSERT INTO Bus (capacity, model, manufacturer, registrationnum, DriverID)
VALUES
('50', 'Volvo', 'Volvo AB', 200001, 1),
('60', 'Mercedes', 'Mercedes-Benz', 200002, 2),
('45', 'Toyota', 'Toyota Motors', 200003, 3),
('55', 'Scania', 'Scania AB', 200004, 4),
('40', 'MAN', 'MAN SE', 200005, 5),
('50', 'Volvo', 'Volvo AB', 200006, 6),
('60', 'Mercedes', 'Mercedes-Benz', 200007, 7),
('45', 'Toyota', 'Toyota Motors', 200008, 8),
('55', 'Scania', 'Scania AB', 200009, 9),
('40', 'MAN', 'MAN SE', 200010, 10),
('50', 'Volvo', 'Volvo AB', 200011, 11),
('60', 'Mercedes', 'Mercedes-Benz', 200012, 12),
('45', 'Toyota', 'Toyota Motors', 200013, 13),
('55', 'Scania', 'Scania AB', 200014, 14),
('40', 'MAN', 'MAN SE', 200015, 15),
('50', 'Volvo', 'Volvo AB', 200016, 16),
('60', 'Mercedes', 'Mercedes-Benz', 200017, 17),
('45', 'Toyota', 'Toyota Motors', 200018, 18),
('55', 'Scania', 'Scania AB', 200019, 19),
('40', 'MAN', 'MAN SE', 200020, 20);


INSERT INTO Routess (routename, pickuplocation, dropofflocation, busID)
VALUES
('Route 1', 'Cairo', 'Giza', 1),
('Route 2', 'Alexandria', 'Mansoura', 2),
('Route 3', 'Luxor', 'Aswan', 3),
('Route 4', 'Fayoum', 'Minya', 4),
('Route 5', 'Cairo', 'Alexandria', 5),
('Route 6', 'Ismailia', 'Suez', 6),
('Route 7', 'Tanta', 'Zagazig', 7),
('Route 8', 'Beni Suef', 'Sohag', 8),
('Route 9', 'Damietta', 'Port Said', 9),
('Route 10', 'Sharm El Sheikh', 'Hurghada', 10),
('Route 11', 'Cairo', 'Giza', 11),
('Route 12', 'Alexandria', 'Mansoura', 12),
('Route 13', 'Luxor', 'Aswan', 13),
('Route 14', 'Fayoum', 'Minya', 14),
('Route 15', 'Cairo', 'Alexandria', 15),
('Route 16', 'Ismailia', 'Suez', 16),
('Route 17', 'Tanta', 'Zagazig', 17),
('Route 18', 'Beni Suef', 'Sohag', 18),
('Route 19', 'Damietta', 'Port Said', 19),
('Route 20', 'Sharm El Sheikh', 'Hurghada', 20);


INSERT INTO trips (statuss, numofseats, pickuptime, dropofftime, busID, routeID)
VALUES
('Active', '40', '2024-12-03 08:00:00', '2024-12-03 10:00:00', 1, 1),
('Cancelled', '35', '2024-12-03 09:00:00', '2024-12-03 11:00:00', 2, 2),
('Completed', '45', '2024-12-03 10:00:00', '2024-12-03 12:00:00', 3, 3),
('Active', '50', '2024-12-03 11:00:00', '2024-12-03 13:00:00', 4, 4),
('Active', '60', '2024-12-03 12:00:00', '2024-12-03 14:00:00', 5, 5),
('Cancelled', '55', '2024-12-03 13:00:00', '2024-12-03 15:00:00', 6, 6),
('Completed', '40', '2024-12-03 14:00:00', '2024-12-03 16:00:00', 7, 7),
('Active', '45', '2024-12-03 15:00:00', '2024-12-03 17:00:00', 8, 8),
('Cancelled', '50', '2024-12-03 16:00:00', '2024-12-03 18:00:00', 9, 9),
('Completed', '60', '2024-12-03 17:00:00', '2024-12-03 19:00:00', 10, 10),
('Active', '40', '2024-12-03 18:00:00', '2024-12-03 20:00:00', 11, 11),
('Cancelled', '35', '2024-12-03 19:00:00', '2024-12-03 21:00:00', 12, 12),
('Completed', '45', '2024-12-03 20:00:00', '2024-12-03 22:00:00', 13, 13),
('Active', '50', '2024-12-03 21:00:00', '2024-12-03 23:00:00', 14, 14),
('Active', '60', '2024-12-04 08:00:00', '2024-12-04 10:00:00', 15, 15),
('Cancelled', '55', '2024-12-04 09:00:00', '2024-12-04 11:00:00', 16, 16),
('Completed', '40', '2024-12-04 10:00:00', '2024-12-04 12:00:00', 17, 17),
('Active', '45', '2024-12-04 11:00:00', '2024-12-04 13:00:00', 18, 18),
('Cancelled', '50', '2024-12-04 12:00:00', '2024-12-04 14:00:00', 19, 19),
('Completed', '60', '2024-12-04 13:00:00', '2024-12-04 15:00:00', 20, 20);


INSERT INTO user_trips (userID, tripsID)
VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(20, 20);




























